-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.0.27-community-nt


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema wildfire
--

CREATE DATABASE IF NOT EXISTS wildfire;
USE wildfire;

--
-- Definition of table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `id` int(11) NOT NULL auto_increment,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` (`email`,`password`,`name`,`id`) VALUES 
 ('11@11.com','96e79218965eb72c92a549dd5a330112','11',1);
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;


--
-- Definition of table `campaign`
--

DROP TABLE IF EXISTS `campaign`;
CREATE TABLE `campaign` (
  `name` varchar(255) NOT NULL,
  `company` varchar(255) default NULL,
  `id` int(10) unsigned NOT NULL auto_increment,
  `i2_survey_id` int(10) unsigned default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `campaign`
--

/*!40000 ALTER TABLE `campaign` DISABLE KEYS */;
INSERT INTO `campaign` (`name`,`company`,`id`,`i2_survey_id`) VALUES 
 ('Eden Juice Bar','Eden Corp.',1,1),
 ('Canon WUX10 Projector','CANON',2,0),
 ('IBM USB Keyboard with UltraNav','IBM',3,0);
/*!40000 ALTER TABLE `campaign` ENABLE KEYS */;


--
-- Definition of table `campaign_invitation`
--

DROP TABLE IF EXISTS `campaign_invitation`;
CREATE TABLE `campaign_invitation` (
  `campaign_id` int(11) NOT NULL,
  `consumer_id` int(11) NOT NULL,
  `create_date` datetime NOT NULL,
  `state` varchar(255) NOT NULL,
  `id` int(10) unsigned NOT NULL auto_increment,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `campaign_invitation`
--

/*!40000 ALTER TABLE `campaign_invitation` DISABLE KEYS */;
INSERT INTO `campaign_invitation` (`campaign_id`,`consumer_id`,`create_date`,`state`,`id`) VALUES 
 (1,2,'2009-02-18 07:21:22','NEW',1),
 (1,4,'2009-02-18 07:58:20','NEW',2),
 (1,7,'2009-02-18 07:23:33','NEW',3),
 (1,8,'2009-02-18 07:34:38','NEW',4),
 (1,10,'2009-02-18 12:28:27','ACCEPTED',5),
 (2,10,'2009-02-18 12:28:32','ACCEPTED',6),
 (3,10,'2009-02-18 12:28:35','ACCEPTED',7),
 (2,5,'2009-02-25 04:16:37','NEW',8),
 (2,7,'2009-02-25 04:16:37','NEW',9),
 (3,8,'2009-02-25 04:34:19','NEW',10),
 (3,9,'2009-02-25 04:34:19','NEW',11),
 (2,6,'2009-02-25 04:37:33','NEW',12),
 (2,8,'2009-02-25 04:37:33','NEW',13);
/*!40000 ALTER TABLE `campaign_invitation` ENABLE KEYS */;


--
-- Definition of table `campaign_participation`
--

DROP TABLE IF EXISTS `campaign_participation`;
CREATE TABLE `campaign_participation` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `campaign_id` int(10) unsigned NOT NULL,
  `consumer_id` int(10) unsigned NOT NULL,
  `campaign_invitation_id` int(10) unsigned NOT NULL,
  `accept_date` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `campaign_participation`
--

/*!40000 ALTER TABLE `campaign_participation` DISABLE KEYS */;
INSERT INTO `campaign_participation` (`id`,`campaign_id`,`consumer_id`,`campaign_invitation_id`,`accept_date`) VALUES 
 (3,1,10,5,'2009-02-20 10:30:30'),
 (4,2,10,6,'2009-02-23 02:46:49'),
 (5,3,10,7,'2009-02-25 05:45:00');
/*!40000 ALTER TABLE `campaign_participation` ENABLE KEYS */;


--
-- Definition of table `consumer`
--

DROP TABLE IF EXISTS `consumer`;
CREATE TABLE `consumer` (
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `id` int(11) NOT NULL auto_increment,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `consumer`
--

/*!40000 ALTER TABLE `consumer` DISABLE KEYS */;
INSERT INTO `consumer` (`email`,`password`,`name`,`id`) VALUES 
 ('111@163.com','698d51a19d8a121ce581499d7b701668','111',2),
 ('2222@11.com','96e79218965eb72c92a549dd5a330112','2222',4),
 ('222@163.com','e3ceb5881a0a1fdaad01296d7554868d','222',5),
 ('2@2.com','fababb5fa238dd7e7ac7c178fba5270b','222',6),
 ('33@test.com','1a100d2c0dab19c4430e7d73762b3423','333',7),
 ('1111@11.com','96e79218965eb72c92a549dd5a330112','1111',8),
 ('1@1.com','96e79218965eb72c92a549dd5a330112','111111',9),
 ('liukai@ostrakon.org','96e79218965eb72c92a549dd5a330112','Liu Kai',10);
/*!40000 ALTER TABLE `consumer` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
