-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.0.22-community


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema wildfire
--

CREATE DATABASE IF NOT EXISTS wildfire;
USE wildfire;

--
-- Definition of table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `id` int(11) NOT NULL auto_increment,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` (`email`,`password`,`name`,`id`) VALUES 
 ('11@11.com','96e79218965eb72c92a549dd5a330112','11',1),
 ('admin','96e79218965eb72c92a549dd5a330112','admin',2);
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;


--
-- Definition of table `campaign`
--

DROP TABLE IF EXISTS `campaign`;
CREATE TABLE `campaign` (
  `name` varchar(255) NOT NULL,
  `company` varchar(255) default NULL,
  `id` int(10) unsigned NOT NULL auto_increment,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `campaign`
--

/*!40000 ALTER TABLE `campaign` DISABLE KEYS */;
INSERT INTO `campaign` (`name`,`company`,`id`) VALUES 
 ('IBM USB Keyboard with UltraNav','IBM',1),
 ('Canon WUX10 Projector','CANON',2),
 ('Test','Ostrakon',3);
/*!40000 ALTER TABLE `campaign` ENABLE KEYS */;


--
-- Definition of table `campaign_invitation`
--

DROP TABLE IF EXISTS `campaign_invitation`;
CREATE TABLE `campaign_invitation` (
  `campaign_id` int(11) NOT NULL,
  `consumer_id` int(11) NOT NULL,
  `create_date` datetime NOT NULL,
  `state` varchar(255) NOT NULL,
  `id` int(11) NOT NULL auto_increment,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `campaign_invitation`
--

/*!40000 ALTER TABLE `campaign_invitation` DISABLE KEYS */;
INSERT INTO `campaign_invitation` (`campaign_id`,`consumer_id`,`create_date`,`state`,`id`) VALUES 
 (1,8,'2009-02-18 10:05:24','NEW',15),
 (1,9,'2009-02-18 10:05:24','ACCEPTED',16),
 (2,9,'2009-02-18 10:30:25','REJECTED',17),
 (3,9,'2009-02-18 10:30:32','REJECTED',18),
 (3,5,'2009-02-18 11:12:50','NEW',19),
 (3,6,'2009-02-18 11:12:50','NEW',20),
 (3,7,'2009-02-18 11:12:50','NEW',21),
 (1,5,'2009-02-20 08:04:05','NEW',22),
 (2,2,'2009-02-20 09:08:26','NEW',23),
 (2,5,'2009-02-20 09:08:26','NEW',24),
 (2,11,'2009-02-20 09:08:26','REJECTED',25),
 (1,11,'2009-02-20 09:13:27','ACCEPTED',26),
 (3,11,'2009-02-20 09:13:33','REJECTED',27),
 (1,12,'2009-02-20 09:19:36','NEW',28),
 (2,12,'2009-02-20 09:19:43','NEW',29),
 (3,12,'2009-02-20 09:19:50','ACCEPTED',30);
/*!40000 ALTER TABLE `campaign_invitation` ENABLE KEYS */;


--
-- Definition of table `campaign_participation`
--

DROP TABLE IF EXISTS `campaign_participation`;
CREATE TABLE `campaign_participation` (
  `id` int(11) NOT NULL auto_increment,
  `campaign_id` int(11) NOT NULL,
  `consumer_id` int(11) NOT NULL,
  `campaign_invitation_id` int(11) NOT NULL,
  `accept_date` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `campaign_participation`
--

/*!40000 ALTER TABLE `campaign_participation` DISABLE KEYS */;
INSERT INTO `campaign_participation` (`id`,`campaign_id`,`consumer_id`,`campaign_invitation_id`,`accept_date`) VALUES 
 (1,1,9,16,'2009-02-19 07:20:29'),
 (2,3,9,18,'2009-02-19 07:20:33'),
 (3,2,11,25,'2009-02-20 09:12:36'),
 (4,1,11,26,'2009-02-20 09:14:00'),
 (5,3,12,30,'2009-02-20 09:20:06');
/*!40000 ALTER TABLE `campaign_participation` ENABLE KEYS */;


--
-- Definition of table `consumer`
--

DROP TABLE IF EXISTS `consumer`;
CREATE TABLE `consumer` (
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `id` int(11) NOT NULL auto_increment,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `consumer`
--

/*!40000 ALTER TABLE `consumer` DISABLE KEYS */;
INSERT INTO `consumer` (`email`,`password`,`name`,`id`) VALUES 
 ('111@163.com','96e79218965eb72c92a549dd5a330112','111',2),
 ('222@163.com','96e79218965eb72c92a549dd5a330112','222',5),
 ('4@4.com','96e79218965eb72c92a549dd5a330112','4444',11),
 ('1@1.com','96e79218965eb72c92a549dd5a330112','111',12);
/*!40000 ALTER TABLE `consumer` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
